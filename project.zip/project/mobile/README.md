# Mobile — Flutter клиент

Android-приложение для семантического поиска файлов. Общается с backend'ом по REST.

## Требования

- Flutter SDK 3.19+
- Android SDK, AVD эмулятор или физическое устройство с Android 7+
- Запущенный backend (см. `../backend/README.md`)

## Запуск

```bash
cd mobile
flutter pub get
flutter run
```

## Подключение к backend'у

| Сценарий                  | URL в настройках             |
|---------------------------|------------------------------|
| Android-эмулятор на том же ПК | `http://10.0.2.2:8000`   |
| Физическое устройство через USB | `http://localhost:8000` + `adb reverse tcp:8000 tcp:8000` |
| Устройство в той же Wi-Fi | `http://<IP_ПК>:8000`       |
| ngrok-туннель             | HTTPS-URL, выданный ngrok     |

URL редактируется в экране «Настройки» и сохраняется в SharedPreferences.

## Структура

```
mobile/lib/
├── main.dart                      # Точка входа, PermissionGate
├── models/
│   ├── search_result.dart         # DTO результата
│   └── index_status.dart          # DTO статуса индексации + enum IndexState
├── services/
│   ├── api_service.dart           # HTTP-клиент к backend'у
│   └── settings_service.dart      # URL сервера, последний путь
├── screens/
│   ├── home_screen.dart           # Поисковая строка, выбор типа
│   ├── results_screen.dart        # Список результатов
│   ├── settings_screen.dart       # URL, статус, переиндексация
│   └── indexing_screen.dart       # Прогресс (polling /status каждые 2 сек)
└── widgets/
    └── file_card.dart             # Карточка одного результата
```

## Разрешения

Запрашиваются при первом запуске через `_PermissionGate`:
- Android 13+: `READ_MEDIA_IMAGES`, `READ_MEDIA_VIDEO`, `READ_MEDIA_AUDIO`
- Android 10–12: `READ_EXTERNAL_STORAGE`
- `MANAGE_EXTERNAL_STORAGE` — нужен, чтобы file_picker возвращал абсолютные пути, а не SAF URI.

Если пользователь навсегда отказал — `_PermissionGate` показывает кнопку «Открыть настройки».

## Известные особенности

- **`MANAGE_EXTERNAL_STORAGE`** при публикации в Google Play требует отдельного одобрения. Для дипломной демонстрации достаточно установки через `flutter run` или APK.
- **`file_picker` на Android 11+** может вернуть SAF URI вместо пути. В этом случае backend не сможет открыть файл. Решение — либо дать `MANAGE_EXTERNAL_STORAGE`, либо индексировать конкретные стандартные директории (`/storage/emulated/0/DCIM`, `/storage/emulated/0/Documents`).
- **Таймауты**: `/search` = 30 сек (inference моделей), `/status` = 5 сек, `/index` = 10 сек.
- **Кириллица в результатах**: декодируется явно через `utf8.decode(response.bodyBytes)` — иначе Dart http парсит как latin-1.
