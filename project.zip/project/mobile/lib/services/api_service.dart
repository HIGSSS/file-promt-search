import 'dart:async';
import 'dart:convert';
import 'dart:io';

import 'package:http/http.dart' as http;

import '../models/index_status.dart';
import '../models/search_result.dart';
import 'settings_service.dart';

/// Типизированная ошибка API: UI отличает «сервер недоступен» от
/// «индекс не построен», чтобы показать понятное сообщение пользователю.
class ApiException implements Exception {
  final String message;
  final int? statusCode;

  const ApiException(this.message, {this.statusCode});

  @override
  String toString() => message;
}

/// Клиент REST API backend'а.
///
/// URL сервера читается из SharedPreferences при каждом запросе —
/// это позволяет менять URL в настройках без пересоздания сервиса.
/// Оверхед SharedPreferences минимальный (in-memory кеш после первого чтения).
class ApiService {
  // Таймауты из §5.7 ТЗ. /search долгий из-за inference моделей,
  // /status лёгкий и должен быстро падать, если сервер не отвечает.
  static const _searchTimeout = Duration(seconds: 30);
  static const _statusTimeout = Duration(seconds: 5);
  static const _indexTimeout = Duration(seconds: 10);

  static Future<Uri> _uri(String path) async {
    final base = await SettingsService.getServerUrl();
    return Uri.parse('$base$path');
  }

  /// Единая точка обработки сетевых ошибок.
  /// SocketException = нет сети / неверный хост / сервер не запущен.
  /// TimeoutException = сервер висит.
  static Future<T> _withErrorHandling<T>(Future<T> Function() op) async {
    try {
      return await op();
    } on SocketException {
      throw const ApiException('Сервер недоступен. Проверьте подключение.');
    } on TimeoutException {
      throw const ApiException('Таймаут запроса. Сервер не отвечает.');
    } on FormatException {
      throw const ApiException('Некорректный ответ сервера (не JSON).');
    } on HttpException catch (e) {
      throw ApiException('HTTP ошибка: ${e.message}');
    }
  }

  /// POST /index — запуск индексации.
  ///
  /// Возвращает сразу; дальнейший прогресс отслеживается через /status.
  /// Статус 'busy' = индексация уже идёт (валидный ответ, не ошибка).
  static Future<void> startIndexing(String path) async {
    await _withErrorHandling(() async {
      final uri = await _uri('/index');
      final response = await http
          .post(
            uri,
            headers: {'Content-Type': 'application/json'},
            body: jsonEncode({'path': path}),
          )
          .timeout(_indexTimeout);

      if (response.statusCode != 200) {
        final detail = _extractDetail(response.body) ?? 'Ошибка ${response.statusCode}';
        throw ApiException(detail, statusCode: response.statusCode);
      }
      // Сохраняем путь для быстрой переиндексации в Settings.
      await SettingsService.setLastIndexedPath(path);
    });
  }

  /// GET /status — текущее состояние индексации.
  static Future<IndexStatus> getStatus() async {
    return _withErrorHandling(() async {
      final uri = await _uri('/status');
      final response = await http.get(uri).timeout(_statusTimeout);

      if (response.statusCode != 200) {
        throw ApiException(
          'Не удалось получить статус',
          statusCode: response.statusCode,
        );
      }
      final json = jsonDecode(utf8.decode(response.bodyBytes)) as Map<String, dynamic>;
      return IndexStatus.fromJson(json);
    });
  }

  /// POST /search — семантический поиск.
  ///
  /// Возвращает пустой список, если ничего не найдено (это не ошибка).
  /// Бросает ApiException(statusCode=400), если индекс не построен —
  /// UI показывает отдельное сообщение для этого случая.
  static Future<List<SearchResult>> search(
    String query,
    String fileType, {
    int topK = 10,
  }) async {
    return _withErrorHandling(() async {
      final uri = await _uri('/search');
      final response = await http
          .post(
            uri,
            headers: {'Content-Type': 'application/json'},
            body: jsonEncode({
              'query': query,
              'file_type': fileType,
              'top_k': topK,
            }),
          )
          .timeout(_searchTimeout);

      if (response.statusCode != 200) {
        final detail = _extractDetail(response.body) ?? 'Ошибка ${response.statusCode}';
        throw ApiException(detail, statusCode: response.statusCode);
      }

      // utf8.decode на bodyBytes, а не на body: body пытается декодировать
      // как latin-1 при отсутствии явного charset в Content-Type, что ломает кириллицу.
      final json = jsonDecode(utf8.decode(response.bodyBytes)) as Map<String, dynamic>;
      final rawResults = json['results'] as List<dynamic>;
      return rawResults
          .map((e) => SearchResult.fromJson(e as Map<String, dynamic>))
          .toList();
    });
  }

  /// Пытается вытащить поле 'detail' из тела FastAPI-ошибки.
  /// FastAPI отдаёт 4xx/5xx как {"detail": "..."} по умолчанию.
  static String? _extractDetail(String body) {
    try {
      final parsed = jsonDecode(body);
      if (parsed is Map<String, dynamic> && parsed['detail'] is String) {
        return parsed['detail'] as String;
      }
    } catch (_) {
      // Тело не JSON — возвращаем null, вызывающий код подставит дефолт.
    }
    return null;
  }
}
