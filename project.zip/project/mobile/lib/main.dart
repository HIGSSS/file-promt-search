import 'dart:io';

import 'package:flutter/material.dart';
import 'package:permission_handler/permission_handler.dart';

import 'screens/home_screen.dart';

void main() {
  runApp(const FileSearchApp());
}

class FileSearchApp extends StatelessWidget {
  const FileSearchApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Intelligent File Search',
      theme: ThemeData(
        colorSchemeSeed: Colors.indigo,
        useMaterial3: true,
      ),
      home: const _PermissionGate(child: HomeScreen()),
      debugShowCheckedModeBanner: false,
    );
  }
}

/// Запрашивает runtime-разрешения перед показом главного экрана.
///
/// Выделено в отдельный виджет, чтобы HomeScreen оставался чистым UI
/// без смешения с permission-логикой. Пока разрешения не даны — показывается
/// экран с объяснением и кнопкой повтора.
class _PermissionGate extends StatefulWidget {
  final Widget child;
  const _PermissionGate({required this.child});

  @override
  State<_PermissionGate> createState() => _PermissionGateState();
}

class _PermissionGateState extends State<_PermissionGate> {
  bool _granted = false;
  bool _checking = true;
  bool _permanentlyDenied = false;

  @override
  void initState() {
    super.initState();
    _check();
  }

  /// Запрашивает нужный набор разрешений в зависимости от версии Android.
  ///
  /// Android 13+ (API 33+): гранулярные READ_MEDIA_IMAGES/VIDEO/AUDIO.
  /// Android 10–12: Permission.storage.
  /// На iOS приложение не поддерживается (§8 ТЗ), проверку пропускаем.
  Future<void> _check() async {
    if (!Platform.isAndroid) {
      setState(() {
        _granted = true;
        _checking = false;
      });
      return;
    }

    // Читаем версию SDK из Platform — но т.к. dart:io не даёт её напрямую,
    // запрашиваем оба набора и смотрим, какой реально применится.
    // permission_handler на неподдерживаемом API вернёт granted автоматически.
    final statuses = await [
      Permission.storage,
      Permission.photos,
      Permission.videos,
    ].request();

    // Разрешение считаем данным, если ХОТЯ БЫ одно из медиа-прав выдано.
    // Это корректно и для Android 12- (даёт storage), и для 13+ (photos/videos).
    final anyGranted = statuses.values.any((s) => s.isGranted);
    final anyPermanentlyDenied =
        statuses.values.any((s) => s.isPermanentlyDenied);

    if (!mounted) return;
    setState(() {
      _granted = anyGranted;
      _permanentlyDenied = anyPermanentlyDenied && !anyGranted;
      _checking = false;
    });
  }

  @override
  Widget build(BuildContext context) {
    if (_checking) {
      return const Scaffold(
        body: Center(child: CircularProgressIndicator()),
      );
    }
    if (_granted) return widget.child;

    return Scaffold(
      body: Padding(
        padding: const EdgeInsets.all(24),
        child: Center(
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              Icon(Icons.folder_off, size: 64, color: Colors.grey.shade600),
              const SizedBox(height: 16),
              const Text(
                'Нужен доступ к файлам',
                style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
                textAlign: TextAlign.center,
              ),
              const SizedBox(height: 8),
              Text(
                'Приложение ищет файлы на устройстве. Без доступа '
                'к медиа и хранилищу поиск не будет работать.',
                textAlign: TextAlign.center,
                style: TextStyle(color: Colors.grey.shade700),
              ),
              const SizedBox(height: 24),
              if (_permanentlyDenied)
                FilledButton.icon(
                  onPressed: openAppSettings,
                  icon: const Icon(Icons.settings),
                  label: const Text('Открыть настройки'),
                )
              else
                FilledButton(
                  onPressed: () {
                    setState(() => _checking = true);
                    _check();
                  },
                  child: const Text('Запросить снова'),
                ),
            ],
          ),
        ),
      ),
    );
  }
}
