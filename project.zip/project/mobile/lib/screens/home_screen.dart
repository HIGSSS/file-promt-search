import 'package:file_picker/file_picker.dart';
import 'package:flutter/material.dart';

import '../services/api_service.dart';
import 'indexing_screen.dart';
import 'results_screen.dart';
import 'settings_screen.dart';

/// Главный экран: строка поиска, выбор типа файлов, запуск поиска
/// и индексации.
class HomeScreen extends StatefulWidget {
  const HomeScreen({super.key});

  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  final _queryController = TextEditingController();
  String _fileType = 'all';
  bool _isLoading = false;

  @override
  void dispose() {
    _queryController.dispose();
    super.dispose();
  }

  Future<void> _performSearch() async {
    final query = _queryController.text.trim();
    if (query.isEmpty) return;

    setState(() => _isLoading = true);
    try {
      final results = await ApiService.search(query, _fileType, topK: 10);
      if (!mounted) return;
      Navigator.push(
        context,
        MaterialPageRoute(
          builder: (_) => ResultsScreen(results: results, query: query),
        ),
      );
    } on ApiException catch (e) {
      if (!mounted) return;
      // 400 = индекс не построен → подсказка с переходом на индексацию.
      // Другие ошибки → просто SnackBar.
      if (e.statusCode == 400) {
        _showIndexPrompt(e.message);
      } else {
        _showError(e.message);
      }
    } finally {
      if (mounted) setState(() => _isLoading = false);
    }
  }

  Future<void> _startIndexing() async {
    // file_picker на Android 11+ часто возвращает SAF URI вместо пути.
    // Для работы с backend'ом (который открывает файлы напрямую) нужен
    // абсолютный путь — реальная работа требует MANAGE_EXTERNAL_STORAGE
    // (разрешение есть в AndroidManifest). На эмуляторе работает стабильно.
    final path = await FilePicker.platform.getDirectoryPath();
    if (path == null) return;

    setState(() => _isLoading = true);
    try {
      await ApiService.startIndexing(path);
      if (!mounted) return;
      Navigator.push(
        context,
        MaterialPageRoute(builder: (_) => const IndexingScreen()),
      );
    } on ApiException catch (e) {
      if (mounted) _showError(e.message);
    } finally {
      if (mounted) setState(() => _isLoading = false);
    }
  }

  void _showError(String message) {
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(content: Text(message), backgroundColor: Colors.red.shade700),
    );
  }

  void _showIndexPrompt(String message) {
    showDialog<void>(
      context: context,
      builder: (ctx) => AlertDialog(
        title: const Text('Индекс не готов'),
        content: Text('$message\n\nХотите проиндексировать папку сейчас?'),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(ctx),
            child: const Text('Отмена'),
          ),
          FilledButton(
            onPressed: () {
              Navigator.pop(ctx);
              _startIndexing();
            },
            child: const Text('Индексировать'),
          ),
        ],
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Поиск файлов'),
        actions: [
          IconButton(
            icon: const Icon(Icons.settings),
            onPressed: () => Navigator.push(
              context,
              MaterialPageRoute(builder: (_) => const SettingsScreen()),
            ),
          ),
        ],
      ),
      body: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            TextField(
              controller: _queryController,
              decoration: const InputDecoration(
                labelText: 'Что искать',
                hintText: 'например: котик у окна',
                prefixIcon: Icon(Icons.search),
                border: OutlineInputBorder(),
              ),
              textInputAction: TextInputAction.search,
              onSubmitted: (_) => _performSearch(),
              // Пересчёт состояния кнопки при каждом вводе: вынесено
              // как отдельный setState, чтобы не создавать лишние сборки
              // при опечатках. Stateful builder не нужен — экран не тяжёлый.
              onChanged: (_) => setState(() {}),
            ),
            const SizedBox(height: 16),
            SegmentedButton<String>(
              segments: const [
                ButtonSegment(value: 'all', label: Text('Все')),
                ButtonSegment(value: 'media', label: Text('Медиа')),
                ButtonSegment(value: 'documents', label: Text('Документы')),
                ButtonSegment(value: 'other', label: Text('Прочие')),
              ],
              selected: {_fileType},
              onSelectionChanged: (s) => setState(() => _fileType = s.first),
              // showSelectedIcon=false экономит место на узких экранах.
              showSelectedIcon: false,
            ),
            const SizedBox(height: 16),
            FilledButton.icon(
              onPressed: (_isLoading || _queryController.text.trim().isEmpty)
                  ? null
                  : _performSearch,
              icon: _isLoading
                  ? const SizedBox(
                      width: 16,
                      height: 16,
                      child: CircularProgressIndicator(
                        strokeWidth: 2,
                        color: Colors.white,
                      ),
                    )
                  : const Icon(Icons.search),
              label: const Text('Найти'),
            ),
            const SizedBox(height: 8),
            TextButton.icon(
              onPressed: _isLoading ? null : _startIndexing,
              icon: const Icon(Icons.folder_open),
              label: const Text('Индексировать папку'),
            ),
          ],
        ),
      ),
    );
  }
}
