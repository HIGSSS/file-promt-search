"""FastAPI-сервер: 3 эндпоинта + lifespan с прогревом моделей.

Запуск:
    uvicorn main:app --host 0.0.0.0 --port 8000

Для adb reverse (USB-подключение телефона):
    adb reverse tcp:8000 tcp:8000
"""
from __future__ import annotations

import logging
from contextlib import asynccontextmanager

from fastapi import BackgroundTasks, FastAPI, HTTPException
from fastapi.middleware.cors import CORSMiddleware

import indexer
import searcher
from config import STORAGE_DIR
from models import warmup
from schemas import (
    IndexRequest,
    IndexResponse,
    IndexStatus,
    SearchRequest,
    SearchResponse,
)

logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s %(levelname)-7s %(name)s: %(message)s",
)
logger = logging.getLogger(__name__)


@asynccontextmanager
async def lifespan(app: FastAPI):
    """Инициализация при старте: директории, модели, ранее построенный индекс."""
    STORAGE_DIR.mkdir(parents=True, exist_ok=True)
    logger.info("Прогрев моделей (может занять 10-30 секунд)...")
    warmup()
    # Если индекс уже был построен ранее — подхватываем его, чтобы /search
    # работал сразу после рестарта без переиндексации.
    if searcher.reload():
        logger.info("Индекс подгружен при старте")
    else:
        logger.info("Индекса нет; запустите /index для построения")
    yield
    # Никакой спец. cleanup не нужен: модели GC соберёт при завершении.


app = FastAPI(
    title="Intelligent File Search",
    version="1.0.0",
    lifespan=lifespan,
)

# CORS открыт, т.к. сервер локальный и запускается только во время разработки.
# В продакшене список origin'ов нужно сузить.
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_methods=["*"],
    allow_headers=["*"],
)


@app.post("/index", response_model=IndexResponse)
async def start_index(req: IndexRequest, background: BackgroundTasks) -> IndexResponse:
    """Запускает фоновую индексацию. Возвращает сразу, не дожидаясь."""
    from pathlib import Path

    root = Path(req.path)
    if not root.is_dir():
        raise HTTPException(
            status_code=400,
            detail=f"Директория не найдена: {req.path}",
        )

    # Атомарно переводим состояние в 'indexing'. Если уже идёт — отбиваем.
    if not indexer.try_start():
        return IndexResponse(status="busy", message="Индексация уже идёт")

    # После завершения — перезагружаем индекс в searcher'е, чтобы /search
    # начал возвращать новые результаты без рестарта сервера.
    background.add_task(
        indexer.run_indexing,
        req.path,
        on_finish=searcher.reload,
    )
    return IndexResponse(status="started", message="Индексация запущена")


@app.get("/status", response_model=IndexStatus)
async def get_status() -> IndexStatus:
    """Текущее состояние индексации. Опрашивается UI каждые 2 секунды."""
    return IndexStatus(**indexer.get_status())


@app.post("/search", response_model=SearchResponse)
async def search_endpoint(req: SearchRequest) -> SearchResponse:
    """Семантический поиск. Требует, чтобы индекс был построен ранее."""
    if not searcher.is_loaded():
        raise HTTPException(
            status_code=400,
            detail="Индекс не найден. Сначала запустите индексацию.",
        )
    try:
        results, elapsed_ms = searcher.measure_search(
            req.query, req.file_type, req.top_k,
        )
    except RuntimeError as exc:
        # Гонка: индекс выгрузили между is_loaded() и search().
        # Маловероятно, но обрабатываем корректно.
        raise HTTPException(status_code=400, detail=str(exc))
    return SearchResponse(results=results, query_time_ms=elapsed_ms)


@app.get("/health")
async def health() -> dict[str, str]:
    """Простой healthcheck для мониторинга и отладки."""
    return {"status": "ok"}
